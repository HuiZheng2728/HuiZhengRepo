
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;





public class judge extends Thread{
	
	static long  first_Report[][] = new long[Main.num_racer][2]; // 2D array to store data
	static long second_reprot[][] = new long [Main.num_racer][3];
	static ConcurrentLinkedQueue<racers> riverQ = new ConcurrentLinkedQueue<>(); // queue for river
															// racers will enqueue correctly
	//static Semaphore riverReleaseMutex = new Semaphore(1); // 
	static Semaphore waitForAll = new Semaphore(1); //semaphore for judge, 
											//everytime judge needs to wait,this semaphore will be called
	racers racer = new racers();
	static int numRemain=Main.num_racer-1;  // this variable will be used to release certain amuont of racer from river group
											//since the last member in the group will be released immediately,
											// so release one less of racer
	
	@Override
	public void run() {
		msg(" Welcome to our final stage, the winner gets 7% ");
		msg(" **** Let's get the race started ****");
		
		while(true){						
			try {
				waitForAll.acquire();	//judge wait for racers to form a group
										// judge will be release by racers when a group is formed.
			} catch (InterruptedException e2) {
				e2.printStackTrace();
			}
			
			racers.riverGroupMutex.release(racer.numLine);//judge will release racers from their group and let them cross the river
		
			if(riverQ.size() == Main.num_racer){ // when all crossed the river, judge will go to next stage
													// judge will need to report
				
				break;
			}
		}
		System.out.println("**** Everybody has finished the race !!!*****");
					
		report_one();    //judge reports time  
		report_two();
		letThemGo();
		
		try {
			waitForAll.acquire();         // after report, judge will wait for all racers to go home
		} catch (InterruptedException e) { // the first racer(goes home last) will release judge, after that judge will go home
	
			e.printStackTrace();
		}
		
		msg(" Looks like you all are going home, I'm going home now." ); 
		msg(" I think I need a ride, anyone? ");
		msg(" hello ...");
			
	}

	
	public void report_one(){ //first report
		
		for(int i=0; i< Main.num_racer ;i++){
		
			System.out.println("racer " + (first_Report[i][0]  ) + " finshed this race in " + first_Report[i][1] );
		}
	}
	
	public void report_two(){  //second report
		for(int i=0; i< Main.num_racer; i++){
			System.out.println("*** racer "+ (i) + " -  detail time of "
					+ " forest,   mountain and river respecitvely: ***");
			System.out.print("                  ");
			for(int j = 0; j < 3 ;j++){
				System.out.print( "      " +second_reprot[i][j] + "       ");
			}
			System.out.println();
		}
	
		
		
		}
	public void letThemGo(){ // the method release racers to go home,
							//racers go home one by one, and will signal next racer that it is 
							// time to go home, the last one (which is the first racer) will signal judge
							
							//my understanding of the project instruction is that racers will go home from last to first
							
		while(true){
			
			if(!Main.racer_array.isEmpty()){
				Main.racer_array.get(numRemain).waitForReport.release();
				System.out.println("racer" + numRemain +  "  goes home " );
				numRemain--;
				if(numRemain < 0){
					break;
				}
			}
		
		}
	}
	
	public static long time = System.currentTimeMillis();

	 public void msg(String m) {
	 System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+":"+m);
	 }

}
