
import java.util.ArrayList;
import java.util.Vector;
import java.util.concurrent.Semaphore;




public class racers extends Thread {
	int myspot; //will be used to locate which index the racer should be for report
	public static long myTime=0;
	public static long totalTime=0;  //these variables records time of each obstacle
	public static long ForestStart=0;
	public static long ForestEnd = 0;
	public static long RiverStart=0;
	public static long RiverEnd=0;
	public static long MtStart=0;
	public static long MtEnd=0;
	static Semaphore semaRank = new Semaphore(1); //racers joint river group queue in this semaphore
	Semaphore waitForReport = new Semaphore(0); //this semaphore will let racers wait for report together
	static Semaphore semaGroup = new Semaphore(1,true); //this semaphore makes sure everyone join group correctly   
	static Semaphore joinGroupMutex = new Semaphore(1); //this semaphore makes sure everyone join group correctly
														//every racer will update currentGroupSize 
	
	static ArrayList<racers> rankList = new ArrayList<>(Main.num_racer);//this array will record how many racers have finished
	
	static Semaphore riverGroupMutex = new Semaphore(0);//racers will wait in thier group until judge release them
	
	static int numLine = 3;// only numLine of racer can cross tiver a the same time..I set it to 3
	static int racersLeft = Main.num_racer;// I need this variable to 
	static int currentGroupSize=0;  ///records how many racers have joined group,it this == numRacers
									// judge will know all racers have cross the river
	static Vector<racers> riverGroup = new Vector<>(Main.num_racer); //vector for river
	public racers(int i) {
		myspot=i;
		
	}
	public racers() {
		
	}


	@Override
	public void run() {
		judge judge = new judge();
		obstacles obs = new obstacles();
		

			try {
				myTime=System.currentTimeMillis();
				goToRest(5000);	
				msg(" starts,he's going fast! ");
				msg(" feels tired, he rests before forest");
				goToRest(5000);					// rest before forest
				
				
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
			
			
			// enter forester
			try{
				msg(" ready for next adventure ");
				msg(" enters forest ");
				ForestStart=System.currentTimeMillis();
			
				while(true){
					if(obs.magicWord(CreateWord(),this)){   // racer enters forester and try to find the key to exit 
															// MagicWord will always return true
															//if racer finds key ,this method will return true immediately
															// else racer will sleep 5000 and then the method return true
						break;
					}
				}
						
			msg(" finally exits forest ");		
			ForestEnd=System.currentTimeMillis()-ForestStart; // calculate time used in forest
			judge.second_reprot[myspot][0]=ForestEnd;   	//adding records to judges report
			
			
	
				
				
				// enter mountain
			MtStart=System.currentTimeMillis();
			msg(" feels tired, he rests before mountain ");
			goToRest(5000);
			msg(" ready for next adventure,he enters mountain");	
				
			obs.passingMt();  				// starts to passing mountain 
											//this method will be explained in obstacle class
				
			MtEnd=System.currentTimeMillis()-MtStart;
			judge.second_reprot[myspot][1]=MtEnd;		//calculate and records time for mountain
			msg(" passed the mountain");		
	
			
			
			//enter river
			msg(" needs a good rest before river" );
			goToRest(5000);					
			msg(" prepares to cross the river");
			joinRiverGroup(); 					// Racers join a group in order to cross the river
												// will explain more in the method
			
			RiverStart = System.currentTimeMillis(); // starts  timer for river
			goToRest(5000);						 //  after being released from the group, racer will start crossing the river,
												// this gotoRest method represents the time used to cross the river.
			
			RiverEnd=System.currentTimeMillis()-RiverStart;
			judge.second_reprot[myspot][2]=RiverEnd;
			totalTime=System.currentTimeMillis()-myTime;

			judge.first_Report[myspot][0] = myspot;		//myspot indicates which racer, each racer has its own number
			judge.first_Report[myspot][1]=totalTime;		//adding records to judges report
														//stops recording time at the moment it is recorded.
			
			msg(" finally crossed river");
			msg(" finishs the race!!!");
			
			semaRank.acquire();			//I used this semaRank to make sure racers join the riverQ correctly
										//the riverQ will indicates how many racers have finish and their rank
			judge.riverQ.add(this);
			Main.num_finished++;		
			if(Main.num_finished == Main.num_racer) judge.waitForAll.release();// judge waits until everyone finishes.
			
			semaRank.release();	// racers will be released from adding them to rank 
			
			
	
			waitForReport.acquire();// racers starts to wait for report
			
			
			if(judge.numRemain == 0){		//when everyone goes home, numRemain will be 0
				judge.waitForAll.release(); // judge will be release from waiting for everyone and he will go home
				}

			}
			catch (Exception e) {
				
			}			
		
			
	}
		
	
	public void joinRiverGroup() throws InterruptedException{
		
		joinGroupMutex.acquire();// mutex for currentGroupSize
		currentGroupSize++;		// correctly update currentGroupSize  is important
		joinGroupMutex.release();
		
		
		
		if(currentGroupSize % numLine == 0 || currentGroupSize == Main.num_racer){
													// when numLine of racers form a group or all racers join a group
													// judge will release the group
			judge.waitForAll.release();
		
		}else{										// if a group is not full,then the racer will wait until the group is full
			msg(" I need a group for river,  guys hurry! ");
			riverGroupMutex.acquire();
			
		}
		
	}
	

	

	public void GetRest(int n) throws InterruptedException{// this rest function will let racers sleep for a certain amount of time
		sleep(n);
		
	}
	
	
	public String CreateWord(){			// creates random magic word for forest
		String word = "";
		for(int i=0; i<4; i++){
			char c = (char)(Main.rand.nextInt('e'-'a') + 'a');
			word +=c;
		}
		
		return word;
	}
	
	
	public void goToRest(int n) throws InterruptedException{
	
		sleep(Main.rand.nextInt(n));

	}
	

	 public void msg(String m) {
	 System.out.println("["+(System.currentTimeMillis()-Main.time)+"] "+getName()+ ":"+m);
	 }
	

	
	
}

