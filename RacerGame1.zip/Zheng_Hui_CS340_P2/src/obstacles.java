import java.io.FileNotFoundException;

import java.util.ArrayList;
import java.util.concurrent.Semaphore;

public class obstacles extends Thread {
	
	
	
	racers racer = new racers();
	static Semaphore semaMountain = new Semaphore(1);//used this semaphore,because only one racer 
													// is allow to pass mountain  at a time.
	public static long time = System.currentTimeMillis();
																			
	// forest

	public boolean magicWord(String myWord,racers r) throws FileNotFoundException, InterruptedException{
		int numword= Main.rand.nextInt(200)+300;        // this method will generate 300-500  words of 4 characters
		ArrayList<String> mwordArray = new ArrayList<>(numword);// the parameter is the key that the racer have
		for(int i=0; i<numword;i++){							// if the key is in the 300 words, racer will be released immediately
			String mword="";							
			for(int j=0; j < 4; j++){
				char c = (char)( Main.rand.nextInt('e'-'a') +'a');   // generate random words 
				mword=mword + c;	
			}
			mwordArray.add(mword);				
		}
		return findMagicWord(mwordArray,myWord,r);
		
	}
	
	
	public  boolean findMagicWord(ArrayList<String> wordList,String w,racers r) throws InterruptedException{	
		for(int i = 0; i<wordList.size(); i++){
			sleep(50);						//with this sleep, racer will find their magic word (if exist) very quickly
			if(w.equals(wordList.get(i))){
				r.msg(" Found the key! Good job!! ");
				return true;
			}
		}
		r.msg(" failed to find the key... now he has to wait!! ");// after search the all random words
		sleep(5000);										//if failed, racer will be punished by sleeping for 5000 ms
		
		return true;
			
	}
	
	
	
	// mountain 
	
	public void passingMt() throws InterruptedException{
		semaMountain.acquire();//only one racer can pass mountain at a given time, 
								// therefore I used this semaphore to make sure no two racers try to pass mountain at a given time
		racer.goToRest(5000); // this goToRest represents the time that the racer needs to pass the mountain.
		semaMountain.release();
	}
	
	

	
	
	 public void msg(String m) {
		 System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+":"+m);
	 }
}


