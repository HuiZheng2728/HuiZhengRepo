import java.io.FileNotFoundException;

import java.util.ArrayList;

public class obstacles extends Thread {
	
	
	racers racer = new racers();
	
	
	// forest
	public boolean magicWord(String myWord) throws FileNotFoundException, InterruptedException{
	
		int numword= Main.rand.nextInt(200)+300;
		
		ArrayList<String> mwordArray = new ArrayList<>(numword);
		for(int i=0; i<numword;i++){
			String mword="";
			for(int j=0; j < 4; j++){
				char c = (char)( Main.rand.nextInt('e'-'a') +'a');   // generate random words 
				mword=mword + c;	
			}
			mwordArray.add(mword);
			
			
		}


		return findMagicWord(mwordArray,myWord);
		
	}
	
	
	public static boolean findMagicWord(ArrayList<String> wordList,String w) throws InterruptedException{
		
		for(int i = 0; i<wordList.size(); i++){
			sleep(50);						//with this sleep, racer will find their magic word (if exist) very quickly
			if(w.equals(wordList.get(i))){
			
				return true;
			}
		}

		yield();
		
		
		yield();
		
		
		return true;
	
			
	}
	
	
	
	// mountain 
	public  synchronized boolean QueueForMt(boolean ready,racers r) throws InterruptedException{
		
		while(Main.vector.size() !=Main.num_racer ){ //racers will wait for all other racers to arrive
			racer.goToRest(10);
		}
		
		while(!Main.vector.isEmpty()){   //once all racers arrived, the mountain vector will start letting the 
										//first one in line to exit the mountain.
			
			if(Main.vector.get(0)== r){  
				
			r.goToRest(2000);    // time used to pass the mountain
			Main.vector.remove(0);//
			ready = true;
			
			return ready;
			}
		
	
		}
		return false;
		
		
	
	}
	}
	
	
	
	
	


