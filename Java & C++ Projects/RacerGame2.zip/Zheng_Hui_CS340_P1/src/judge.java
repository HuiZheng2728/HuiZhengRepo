
import java.util.concurrent.ConcurrentLinkedQueue;





public class judge extends Thread{
	public static int num_record = 0;
	public static  long  first_Report[][] = new long[Main.num_racer][2];
	public static long second_reprot[][] = new long [Main.num_racer][3];
	public static ConcurrentLinkedQueue<racers> riverQ = new ConcurrentLinkedQueue<>(); 
	racers racer = new racers();
	@Override
	public void run() {
		msg("**** Let's get the race started ***");
		while(true){
		 try {
			racer.goToRest(1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 while(riverQ.isEmpty() == false){   //adding racer to river queue and interrupt one once awhile
					if(!riverQ.element().isInterrupted()){
						JudgeInt(riverQ.element());
						riverQ.poll();    	//always interrput the first one in queue and remove after
					}
			
			}
		if(num_record== Main.num_racer){
			
			try {
				sleep(3000);   //make sure all racers go home 
				report_one();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			report_two();
			break;
			}
					
		}
	}
				
				
				
	public void JudgeInt(racers r){
		
			r.msg("judge slaps the racer in the face and the racer wakes up ");
			r.interrupt();
		}
	
	
	public void report_one() throws InterruptedException{
		
		for(int i=0; i< Main.num_racer ;i++){
		
			System.out.println("racer " + (first_Report[i][0] +1 ) + " finshed this race in " + first_Report[i][1] );
		}
	}
	
	public void report_two(){
		for(int i=0; i< Main.num_racer; i++){
			System.out.println("*** racer "+ (1+i) + " -  detail time of forest,mountain and river respecitvely: ***");
			for(int j = 0; j < 3 ;j++){
				System.out.print( "         " +second_reprot[i][j] + "           ");
			}
			System.out.println();
		}
	}
	
	
	public static long time = System.currentTimeMillis();

	 public void msg(String m) {
	 System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+":"+m);
	 }

}
