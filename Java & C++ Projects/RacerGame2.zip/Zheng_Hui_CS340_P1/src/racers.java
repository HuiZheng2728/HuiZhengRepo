import java.io.FileNotFoundException;


public class racers extends Thread {
	
	public volatile static boolean ready = false;
	public volatile static boolean alive =true;
	public volatile static int myFirend = 0;
	public volatile  int myspot = 0;
	public volatile static long myTime=0;
	public volatile static long totalTime=0;
	public volatile static long FStart=0;
	public volatile static long Fend = 0;
	public volatile static long RStart=0;
	public volatile static long REnd=0;
	public volatile static long MStart=0;
	public volatile static long MEnd=0;
	public volatile static long RTime=0;
	public volatile static long RiverTime=0;
		public volatile static boolean gohome = false;

	@Override
	public void run() {
	
		judge judge = new judge();
		obstacles obs = new obstacles();
		myspot = myIndex();         //I use myspot to keep record of which racer is in which index of the arraylist
	
			try {
				myTime=System.currentTimeMillis();
				goToRest(5000);
				msg(" started ");
				
				goToRest(5000);
				
				
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			
			
			
			// enter forester
			try{
				msg(" enters forest ");
				FStart=System.currentTimeMillis();
				rush();
				
				while(true){
					
					if(obs.magicWord(CreateWord())){   // racer enters forester and try to find the key to exit 
						break;
				}
				}
						
				
				msg(" exits forest ");
				
				Fend=System.currentTimeMillis()-FStart;
				
				judge.second_reprot[myspot][0]=Fend;   //adding records to judges report
				goToRest(5000);
				setPriority(5);      
				MStart=System.currentTimeMillis();
			
	
			// enter mountain
			
			
			Main.vector.add(this);
			
		
				msg(" enters mountain");
				
				while(!ready){
					if(obs.QueueForMt(ready, this)){ //passing through mountain
						ready = true;
					}
				}
				goToRest(5000);
				
				MEnd=System.currentTimeMillis()-MStart;
				judge.second_reprot[myspot][1]=MEnd;
				msg(" exits mountain");
	
			
			
			//enter river
			
			msg("prepares to cross the river");
			
			judge.riverQ.add(this);
			
			try{
			sleep(50000);       //racer take long nap before exiting river
			}catch(InterruptedException e){
				
			}
			
			RStart = System.currentTimeMillis();
				
			try{
			goToRest(5000);
			}catch(InterruptedException e){
				
			}
			
			REnd=System.currentTimeMillis()-RStart;
			judge.second_reprot[myspot][2]=REnd;
			totalTime=System.currentTimeMillis()-myTime;
			
			judge.first_Report[myspot][0] = myspot;
			judge.first_Report[myspot][1]=totalTime;//adding records to judges report
													//stops recording time at the moment it is recorded.
			judge.num_record++;
			msg("finishs river");
			msg("finishs the race!!!"); 
				
			
			
			//wait for friend
			findMyFriend();					//racer finishs the game but still neeed to wait for their friends.
			msg("waiting for his/her friend to finish");
		
			
				while(gohome!= true){
					gohome=waitiForFriend();
					sleep(10);
					}
	
			msg("goes home");
			
			} catch (InterruptedException | FileNotFoundException e) {
				
				e.printStackTrace();
			}
			
			
	}
		
	
	public synchronized boolean  waitiForFriend() throws InterruptedException{
		if(Main.racer_array.get(myFirend).isAlive() && myFirend!=Main.num_racer-1) {
				Main.racer_array.get(myFirend).join();
						
		}
		
		return true;
	}


	public synchronized int myIndex(){
		for(int i=0; i<Main.racer_array.size(); i++){
			if(this == Main.racer_array.get(i)){
				myspot = i;
				return myspot;
		}
		}
			return myspot;
	}
	
	public synchronized int findMyFriend(){
		for(int i=0; i<Main.racer_array.size()-1; i++){
		
			if(this == Main.racer_array.get(i)){
				
				myFirend = i+1;
				return myFirend;	
			}
		}
		return Main.num_racer-1; //the last racer,does not have a friend, goes home alone   :(
	}
	
	public void rush(){
	
		setPriority(getPriority() + Main.rand.nextInt(5));
		
	}
	
	public void GetRest(int n) throws InterruptedException{
		int sleepTime =Main.rand.nextInt(n);
		sleep(sleepTime);
		
	}
	
	
	public String CreateWord(){
		String word = "";
		for(int i=0; i<4; i++){
			char c = (char)(Main.rand.nextInt('e'-'a') + 'a');
			word +=c;
		}
		
		return word;
	}
	
	
	public void goToRest(int n) throws InterruptedException{
		sleep(Main.rand.nextInt(n));
	}
	
	
	

	 public void msg(String m) {
	 System.out.println("["+(System.currentTimeMillis()-Main.time)+"] "+getName()+ ":"+m);
	 }
	

	
	
}

