
import java.util.ArrayList;
import java.util.Random;
import java.util.Vector;




public class Main {
	

	static Random rand = new Random();
	static int num_racer =10;   //default num of racers
	static int num_finished =0;
	public static volatile long time = System.currentTimeMillis();
	static Vector<racers> vector = new Vector<>(num_racer);   // for mountain queue
	static ArrayList<racers> racer_array = new ArrayList<>(num_racer);    
	
	public static void main(String[] args) throws InterruptedException{
		
		try{
			
		num_racer=Integer.parseInt(args[0]);    //num_racer = args[0], since args[] is string,hence convert to int.
		
		}catch (Exception e) {
			System.out.println(" args value not found");
			// TODO: handle exception
		}
		judge judge = new judge();//create judge thread and racers thread and start them.
		judge.setName("Judge");
		judge.start();
		for(int i=0; i<num_racer; i++){
			racers racer = new racers();	
			racer.setName("racer" + i);	//naming threads
			racer_array.add(racer);
			racer.start();	
		}
			
	}
	
	

	

		
		

}
